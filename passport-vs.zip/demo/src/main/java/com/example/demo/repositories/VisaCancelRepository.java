package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.VisaCancel;

public interface VisaCancelRepository extends JpaRepository<VisaCancel, Long> {

}
